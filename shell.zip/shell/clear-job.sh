#!/bin/bash
#清除队列表数据，每晚23:50执行一次
#50 23 * * * www /home_path/shell/clear-job.sh >> /dev/null 2>&1

$(curl 'http://localhost/cron/clear-job')
