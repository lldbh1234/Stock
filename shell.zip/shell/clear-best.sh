#!/bin/bash
#删除最优持仓中已平仓的策略,交易时间段10分钟运行一次
#*/10 * * * * www /home_path/shell/clear-best.sh >> /dev/null 2>&1

$(curl 'http://localhost/cron/clear-best')
