#!/bin/bash
#最优持仓数据更新
#5 10,13 * * * www /home_path/shell/best-order.sh >> /dev/null 2>&1

$(curl 'http://localhost/cron/best-order')
